import java.util.*;
class Qu17
{
 public static void main(String args[])
{
 int carry=0,i=0;
int[] sum=new int[10];
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter first binary no");
  int n1=sc.nextInt();
  System.out.println("Enter second binary no");
  int n2=sc.nextInt();

while(n1!=0 || n2!=0)
{
sum[i++]= ((n1%10+n2%10+carry)%2);
carry= (n1%10+n2%10+carry)/2;
//System.out.println("addition is "+sum+" "+carry);
n1=n1/10;
n2=n2/10;
}

if(carry==1)
sum[i++]=carry;
else
--i;
while(i>=0)
System.out.print(sum[i--]);
}}