

class Qu5
{
 public static void main(String args[])
{
 int n1=25;
 int n2=5;
 System.out.println(n1+" x "+n2+" = "+n1*n2);
}
}