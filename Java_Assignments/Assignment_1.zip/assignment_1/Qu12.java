import java.util.*;
class Qu12{
 public static void main(String[] args)
{
  Scanner sc= new Scanner(System.in);
  float n1=sc.nextFloat();
  float n2=sc.nextFloat();
  float n3=sc.nextFloat();
float avg;
 avg=(n1+n2+n3)/3;
System.out.println("avg of three no is :"+avg);
}
}