import java.util.*;
class Qu18
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enterfirst binary no");
int n1=sc.nextInt(); 
System.out.println("enter second binary no");
int n2=sc.nextInt();
int count=0,r1,r2,i=0;
int [] rem=new int[10];
while(n1!=0 || n2!=0)
{ 
r1=n1%10;
r2=n2%10;
rem[i++]=r1*r2;
n1=n1/10;
n2=n2/10;
count++;
}
while(i>=0)
System.out.print(rem[i--]);

//System.out.println(rem);
}

}