class Qu14
{
 public static void main(String args[])
 {
  int count=0;
  for (int i=0;i<=6;i++)
   {
     while(count!=9)
     {
	if(count%2==0)
	{
	for(int j=0;j<=5;j++)
 	 {
		System.out.print("* ");
 
	 }
        for(int j1=0;j1<36;j1++)
	        System.out.print("=");
	}
	else
	 {      
		for(int k=0;k<=4;k++)  
		System.out.print(" *");

        System.out.print("  ");	 
        for(int k1=0;k1<36;k1++)
	        System.out.print("=");
         }	
	count++;
      
	System.out.println("");
    }
}
for(int m=0;m<6;m++)
 {for(int p=0;p<48;p++)
   System.out.print("=");
 
 System.out.println("");
}}
}