class Qu11
{
 public static void main(String[] args)
{ double PI=Math.PI;
  float r=7.5F;
  System.out.println("Perimeter is   "+(2*PI*r));
  System.out.println("Area is   "+(PI*r*r));
  
  


}
}