import java.util.*;class Qu6
{
 public static void main(String[] args)
{
  int n1=125;
  int n2=24;
 
 System.out.println(n1+" + "+n2+" = "+ (n1+n2));
 System.out.println(n1+" - "+n2+" = "+ (n1-n2));
 System.out.println(n1+" x "+n2+" = "+ (n1*n2));
 System.out.println(n1+" / "+n2+" = "+ (n1/n2));
 System.out.println(n1+" % "+n2+" = "+ (n1%n2));

}
}