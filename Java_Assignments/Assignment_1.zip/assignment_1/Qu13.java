class Qu13{
 public static void main(String[] args)
{
  double h=8.5D;
  double w=5.5D;
System.out.println("Area is "+w+" and "+h+" ="+w*h);

System.out.println("Perimeter is 2*("+w+" + "+h+")"+" = "+2*(w+h));
}
}