import java.util.*;
class Qu15
{
  public static void main(String args[])
{
Scanner sc= new Scanner(System.in);
System.out.println("Enter n1 and n2");
int n1=sc.nextInt();
int n2=sc.nextInt();

int temp;
/*temp=n1;
n1=n2;
n2=temp;*/

/*n1=n1+n2;
n2=n1-n2;
n1=n1-n2;
*/
n1=n1^n2;
n2=n1^n2;
n1=n1^n2;
System.out.println("After swapping");

System.out.println("n1= "+n1);
System.out.println("n2= "+n2);
}
}