import java.util.*;
class P7
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
 System.out.println("Enter no");
int no=sc.nextInt();
int i,j,k,l;
/*for(int i=1;i<=no;i++)
{
for(int j=1;j<=i;j++)
System.out.print("  ");
for(int k=no;k>=i;k--)
System.out.print(k+" ");
System.out.println();
}*/

for(i=no;i>=1;i--)
{
for(j=i;j<=no;j++)
System.out.print(" ");
for(k=i;k>=1;k--)
System.out.print(i+" ");
System.out.println("");
}
}
}