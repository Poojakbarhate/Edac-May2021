import java.util.*;
class P11
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
 System.out.println("Enter no");
int no=sc.nextInt();
int i,j,k,l;
for(i=no;i>=1;i--)
System.out.print("*");
System.out.println("");
for(j=no-1;j>=2;j--)
{
System.out.print("*");
for(i=j;i>2;i--)
System.out.print(" ");
System.out.println("*");
}
System.out.print("*");
}
}