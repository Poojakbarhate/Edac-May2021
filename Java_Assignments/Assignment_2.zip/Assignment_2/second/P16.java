import java.util.*;
class P16
{
public static void main(String args[])
{
int i,j,k;
Scanner sc=new Scanner(System.in);
 System.out.println("Enter no");
int no=sc.nextInt();
int temp=no;
for(i=1;i<=no;i++)
System.out.print(" ");
System.out.println("*");
//System.out.println("");

for(i=1;i<no;i++)
System.out.print(" ");
System.out.print("**");
System.out.println("");
for(i=1;i<=no;i++)
{
for(j=no;j>2;j--)
System.out.print(" ");
System.out.print("*");
no--;
for(k=1;k<=i;k++)
System.out.print(" ");
System.out.print("*");
System.out.println(" ");
}
System.out.print(" ");
for(i=0;i<temp;i++)
System.out.print("*");
 

//System.out.println("");
}
}