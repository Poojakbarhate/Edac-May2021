import java.util.*;
class P13
{
public static void main(String args[])
{
int i,j,k,l;
Scanner sc=new Scanner(System.in);
 System.out.println("Enter no");
int no=sc.nextInt();
for(i=1;i<=no;i++)
{
for(j=1;j<=i;j++)
 System.out.print(" ");
for(k=no;k>=i;k--)
 System.out.print("*");
System.out.println("");
}
for(k=1;k<=no;k++)
{for(l=no-1;l>=k;l--)
 System.out.print(" ");
for(j=0;j<=k;j++)
System.out.print("*");

System.out.println("");
}
}
}