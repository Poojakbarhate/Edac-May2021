import java.util.*;
class P7
{
public static void main(String args[])
{
int i,j,k,l;
Scanner sc=new Scanner(System.in);
 System.out.println("Enter no");
int no=sc.nextInt();
for(i=1;i<=no;i++)
{
for(j=no;j>=i;j--)
System.out.print(" ");
for(k=1;k<=i;k++)
System.out.print("*");

for(l=1;l<i;l++)
System.out.print("*");
System.out.println();
}
for(i=1;i<=no;i++)
{
for(j=0;j<=i;j++)
System.out.print(" ");
for(k=no-1;k>i;k--)
System.out.print("*");
for(l=i;l<no;l++)
System.out.print("*");
System.out.println();

}
}}