import java.util.*;
class P2
{
public static void main(String args[])
{
int i,j;
Scanner sc=new Scanner(System.in);
 System.out.println("Enter no");
int no=sc.nextInt();
for(i=1;i<=no;i++)
{
for(j=1;j<=i;j++)
 System.out.print((char)(i+64)+" ");
System.out.println("");
}
}
}