import java.util.*;
class P17
{
public static void main(String args[])
{
int i,j,n=1;
Scanner sc=new Scanner(System.in);
 System.out.println("Enter no");
int no=sc.nextInt();
for(i=no;i>=1;i--)
{
for(j=no;j>=i;j--)
 {
System.out.print(n+" ");
n++;
}System.out.println("");
}
}
}