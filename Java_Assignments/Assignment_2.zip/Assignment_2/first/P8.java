import java.util.*;
class P8
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
 System.out.println("Enter no");
int no=sc.nextInt();
int i,j,k,a=1;

for(i=no;i>=1;i--)
{
for(j=1;j<i;j++)
System.out.print(" ");
for(k=i;k<=no;k++)
System.out.print(k+" ");

System.out.println();
}
}
}