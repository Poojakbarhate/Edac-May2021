import java.util.*;
class Swap
{
public static void main(String args[])
{
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter first number");
  int n1=sc.nextInt();
    
  System.out.println("Enter second number");
  int n2=sc.nextInt();
  
  System.out.println("The no before swapping");
  System.out.println("n1= "+n1+" and n2= "+n2);
  n1=n1+n2;
  n2=n1-n2;
  n1=n1-n2;

  System.out.println("The no after swapping");
  System.out.println("n1= "+n1+" and n2= "+n2);
}
}