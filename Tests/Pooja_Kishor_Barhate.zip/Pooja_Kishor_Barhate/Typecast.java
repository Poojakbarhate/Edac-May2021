
class Typecast
{
  public static void main(String args[])
{
int a=10;
float f=20.0f;
double d=30;
char ch='P';
System.out.println("int= "+a);
System.out.println("float= "+f);
System.out.println("double= "+d);
System.out.println("char= "+ch);
float d1=a;
double a1=f;
 int a2=ch;
System.out.println("Integer is typecast to float= "+d1);

System.out.println("Float is typecast to Double "+a1);

System.out.println("Character is typecast to Integer "+a2);

}
}