import java.util.*;
class Eo
{
public static void main(String args[])
{
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter first number");
  int n1=sc.nextInt();
  
  if(n1%2==0)
  System.out.println("Given no is Even ");
  else
  System.out.println("Given no is odd");
}
}