import java.util.*;
class Add
{
public static void main(String args[])
{
int n1=Integer.parseInt(args[0]);
int n2=Integer.parseInt(args[1]);  

System.out.println("The addition of "+n1+" and "+n2+" is "+(n1+n2));
}
}