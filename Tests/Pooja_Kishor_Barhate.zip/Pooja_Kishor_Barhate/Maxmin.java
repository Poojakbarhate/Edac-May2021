import java.util.*;
class Maxmin
{
public static void main(String args[])
{
 int i,j=0;
 Scanner sc=new Scanner(System.in);
 System.out.println("Enter no you want");
 int a=sc.nextInt();
 if(a==2)
{
  System.out.println("Enter 1st no");
  int n1=sc.nextInt();
  System.out.println("Enter 2nd no");
  int n2=sc.nextInt();
  int no= n1>n2?n1:n2;
  System.out.println("greater no is "+no);
  
}
 else if(a==3)
{
  System.out.println("Enter 1st no");
  int n1=sc.nextInt();
  System.out.println("Enter 2nd no");
  int n2=sc.nextInt();
  System.out.println("Enter 3st no");
  int n3=sc.nextInt();
  int n4=n3>(n1>n2?n1:n2)?n3:((n1>n2)?n1:n2);
  System.out.println("Greater no is "+n4);
}}}