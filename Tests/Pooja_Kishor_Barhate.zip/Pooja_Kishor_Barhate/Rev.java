import java.util.*;
class Rev
{
public static void main(String args[])
{
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter number");
  int n1=sc.nextInt();
  System.out.println("Enter array element");
  int a[]= new int[n1];
  int i;
  for(i=0;i<n1;i++)
     a[i]=sc.nextInt();
  
  System.out.println("Array elements in reverse order");
  for(i=n1-1;i>=0;i--)
  System.out.print(a[i]+" ");
}
}

